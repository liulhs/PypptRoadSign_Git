from PypptRoadSign.sign import Sign
import subprocess


subprocess.run(["python", "background_json.py"])